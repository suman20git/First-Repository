import { LightningElement } from 'lwc';

export default class GrandParent extends LightningElement {
   count ;
   totalLength;



    showDispatch(event){
       const {count,totalLength} = event.detail;
        this.count = count;
        this.totalLength = totalLength;
    }

    handleReset() {
        const parent = this.template.querySelector('c-parent');
        if (parent) {
            parent.resetChild();
            this.count =0;

        } else {
            console.error('Parent not found');
        }
    }
        
    }
