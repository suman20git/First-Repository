import { api, LightningElement, track } from 'lwc';

export default class Child extends LightningElement {
    connectedCallback() {
        this.handleDispatchChild();
    }
    @track child_component = [
        {
            title: "Child One",
            buttonLabel: 'Select',
            status: "Deselected",
            icon: "standard:avatar",
            variant: "success",
            index: 1
        },
        {
            title: "Child Two",
            buttonLabel: 'Select',
            status: "Deselected",
            icon: "standard:avatar",
            variant: "success",
            index: 2

        },
        {
            title: "Child Three",
            buttonLabel: 'Select',
            status: "Deselected",
            icon: "standard:avatar",
            variant: "success",
            index: 3
        }
        // ,
        // {
        //     title: "Child Four",
        //     buttonLabel: 'Select',
        //     status: "Deselected",
        //     icon: "standard:avatar",
        //     variant: "success",
        //     index: 4
        // },
        // {
        //     title: "Child Five",
        //     buttonLabel: 'Select',
        //     status: "Deselected",
        //     icon: "standard:avatar",
        //     variant: "success",
        //     index: 5
        // }
    ]
    @api resetData() {
        this.child_component = this.child_component.map(item => ({
            ...item,
            status: 'Deselected',
            buttonLabel: 'Select',
            variant: 'success'
        }));
    }

    clickSelect(event) {
        const childIndex = Number(event.target.dataset.id);
        const fieldIndex = this.child_component.findIndex(f => f.index === childIndex);
        if (fieldIndex === -1) return;

        const childObject = this.child_component[fieldIndex];
        this.child_component[fieldIndex] = {
            ...childObject,
            status: childObject.status === "Deselected" ? "Selected" : "Deselected",
            buttonLabel: childObject.status === "Deselected" ? "Deselect" : "Select",
            variant: childObject.status === "Deselected" ? "brand" : "success",
        }
        this.handleDispatchChild();
    }

    handleDispatchChild() {
        const customEvent = new CustomEvent("save", {
            detail: this.child_component
        });
        this.dispatchEvent(customEvent);
    }
}