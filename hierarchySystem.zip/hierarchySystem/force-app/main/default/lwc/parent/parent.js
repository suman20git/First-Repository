import { api, LightningElement, track } from 'lwc';

export default class Parent extends LightningElement {
    @track updatedChildComponent;
    @track count = 0;
    @track totalLength;
    @api resetData;

     @api resetChild() {
        const child = this.template.querySelector('c-child');
        if (child) {
            child.resetData();
            
            this.updatedChildComponent = this.updatedChildComponent.map(item => ({
            ...item,
            status: 'Deselected',
            buttonLabel: 'Select',
            variant: 'success'
        }));
        } else {
            console.error('Child not found');
        }
    }

    connectedCallback(){
        this.handleDispathParent();
    }

    handleSave(event) {
        this.updatedChildComponent = event.detail;
        console.log('child_component in parent:', this.updatedChildComponent);
        this.selectCount();
    }


    selectCount() {
        let countValue = this.updatedChildComponent.filter((element)=>{
            if(element.status == "Selected"){
                return element;
            }
        })
        this.count = countValue.length;
        this.totalLength = this.updatedChildComponent.length;
        console.log("Testong",this.totalLength)
        this.handleDispathParent();
    }

    handleDispathParent() {
    this.dispatchEvent(new CustomEvent('lint', {
        detail: {
            count: this.count,
            totalLength: this.totalLength
        }
    }));
}

    


}